
-- --------------------------------------------------------

--
-- Структура таблицы `header`
--

CREATE TABLE `header` (
  `id` int(11) NOT NULL,
  `header` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `header`
--

INSERT INTO `header` (`id`, `header`) VALUES
(1, '<div><header><h3>Сидения</h3></header></div>'),
(2, '<div><header><h3>Ткани</h3></header></div>');
