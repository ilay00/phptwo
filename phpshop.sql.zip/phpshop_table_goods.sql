
-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `id_header` int(11) NOT NULL,
  `img` text NOT NULL,
  `footer` text NOT NULL,
  `prase` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `id_header`, `img`, `footer`, `prase`) VALUES
(1, 1, '<div><img src=\"img/prod1.jpg\"> </div>', ' <div><footer><h4>$10</h4>\r\n<h3>\r\n<a href=index.php?c=page&act=Product>Подробней</a>\r\n</h3>\r\n\r\n\r\n\r\n</footer></div>', 10),
(2, 2, '<div><img src=\"img/prod2.jpg\"> </div>\r\n', ' <div><footer><h4>$10</h4>\r\n<h3>\r\n<a href=index.php?c=page&act=Product1>Подробней</a>\r\n</h3>\r\n\r\n</footer></div>', 10);
