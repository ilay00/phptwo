
-- --------------------------------------------------------

--
-- Структура таблицы `prod`
--

CREATE TABLE `prod` (
  `id` int(11) NOT NULL,
  `id_header` int(11) NOT NULL,
  `img` text NOT NULL,
  `opis` text NOT NULL,
  `footer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `prod`
--

INSERT INTO `prod` (`id`, `id_header`, `img`, `opis`, `footer`) VALUES
(1, 1, ' <div><img src=\"img/prod1.jpg\"> </div>\r\n', 'Метолическая', ' <div><footer><h4>$10</h4></footer></div>'),
(2, 2, ' <div><img src=\"img/prod2.jpg\"> </div>', 'синтетика хлопок ', '<div><footer><h4>$10</h4>\r\n\r\n\r\n\r\n</footer></div>');
