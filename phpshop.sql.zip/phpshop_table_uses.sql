
-- --------------------------------------------------------

--
-- Структура таблицы `uses`
--

CREATE TABLE `uses` (
  `id` int(11) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `header` varchar(256) DEFAULT NULL,
  `col` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `uses`
--

INSERT INTO `uses` (`id`, `name`, `tel`, `header`, `col`) VALUES
(25, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(26, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(27, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(28, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(29, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(30, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(31, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(32, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1');
