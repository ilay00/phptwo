
-- --------------------------------------------------------

--
-- Структура таблицы `user_name`
--

CREATE TABLE `user_name` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `header` varchar(100) NOT NULL,
  `col` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_name`
--

INSERT INTO `user_name` (`id`, `name`, `tel`, `header`, `col`) VALUES
(117, 'laic', '+12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(118, 'laic', '+12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(119, 'laic', '+12345566853', '<div><header><h3>Сидения</h3></header></div>', '1'),
(120, 'laic', '+12345566853', '<div><header><h3>Сидения</h3></header></div>', '1'),
(121, '', '  ', '', ''),
(122, '', '  ', '', ''),
(123, '', '  ', '', ''),
(124, '', '  ', '', ''),
(125, 'lol', '+12345566111', '<div><header><h3>Сидения</h3></header></div>', '2'),
(126, 'lol', '+12345566111', '<div><header><h3>Сидения</h3></header></div>', '2'),
(127, '', '  ', '', ''),
(128, '', '  ', '', ''),
(129, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(130, 'laic', ' +12345566789', '<div><header><h3>Ткани</h3></header></div>', '1'),
(131, 'hssu', '+12345566853', '<div><header><h3>Сидения</h3></header></div>', '1'),
(132, 'hssu', '+12345566853', '<div><header><h3>Сидения</h3></header></div>', '1'),
(133, 'df', '+12345566567', '<div><header><h3>Сидения</h3></header></div>', '1'),
(134, 'df', '+12345566567', '<div><header><h3>Сидения</h3></header></div>', '1'),
(135, 'fri', '+12345566789', '<div><header><h3>Сидения</h3></header></div>', '1'),
(136, 'fri', '+12345566789', '<div><header><h3>Сидения</h3></header></div>', '1'),
(137, 'df', '+12345566567', '<div><header><h3>Ткани</h3></header></div>', '1'),
(138, 'df', '+12345566567', '<div><header><h3>Ткани</h3></header></div>', '1'),
(139, 'fri', '+12345566789', '<div><header><h3>Сидения</h3></header></div>', '1'),
(140, 'fri', '+12345566789', '<div><header><h3>Сидения</h3></header></div>', '1'),
(141, 'hp', '+12345566853', '<div><header><h3>Сидения</h3></header></div>', '1'),
(142, 'hp', '+12345566853', '<div><header><h3>Сидения</h3></header></div>', '1'),
(143, 'lol', '+12345566789', '<div><header><h3>Сидения</h3></header></div>', '1'),
(144, 'lol', '+12345566789', '<div><header><h3>Сидения</h3></header></div>', '1');
